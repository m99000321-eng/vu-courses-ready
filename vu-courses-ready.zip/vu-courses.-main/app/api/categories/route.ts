import { NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'

export async function GET() {
  try {
    const categories = await prisma.category.findMany({
      orderBy: { name: 'asc' },
    })
    return NextResponse.json({ categories })
  } catch (_error: any) {
    return NextResponse.json({ error: 'فشل جلب الأقسام' }, { status: 500 })
  }
}
